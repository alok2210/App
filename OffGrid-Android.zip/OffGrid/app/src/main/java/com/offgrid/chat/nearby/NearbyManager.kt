package com.offgrid.chat.nearby

import android.Manifest
import android.content.Context
import android.os.Build
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import java.io.File

/** Permissions Nearby Connections needs on this device. */
fun requiredPermissions(): Array<String> {
    val perms = mutableListOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        perms += Manifest.permission.BLUETOOTH_SCAN
        perms += Manifest.permission.BLUETOOTH_ADVERTISE
        perms += Manifest.permission.BLUETOOTH_CONNECT
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        perms += Manifest.permission.NEARBY_WIFI_DEVICES
    }
    return perms.toTypedArray()
}

/** Everything the transport can tell the UI about. */
sealed interface NearbyEvent {
    data class Info(val message: String) : NearbyEvent
    data class PeerFound(val endpointId: String, val name: String) : NearbyEvent
    data class PeerLost(val endpointId: String) : NearbyEvent
    data class Connected(val endpointId: String, val name: String) : NearbyEvent
    data class Disconnected(val endpointId: String) : NearbyEvent

    /** The shared pairing token for a peer; the crypto layer salts its key with this. */
    data class AuthenticationToken(val endpointId: String, val token: String) : NearbyEvent

    /** A raw (still enveloped) payload arrived from a peer. */
    data class PayloadReceived(val endpointId: String, val bytes: ByteArray) : NearbyEvent
}

/**
 * Thin wrapper around Google Nearby Connections. Advertises this phone and
 * discovers others at the same time (P2P_CLUSTER), then moves raw byte payloads
 * directly over Bluetooth / Wi-Fi Direct. It knows nothing about encryption or
 * message types — that lives above it in the ViewModel.
 *
 * Small payloads go as bytes; larger ones (media) go as file payloads, which
 * Nearby streams to the other side automatically.
 */
class NearbyManager(private val context: Context) {

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context)
    private val serviceId = "com.offgrid.chat.SERVICE"

    private val _events = MutableSharedFlow<NearbyEvent>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val events: SharedFlow<NearbyEvent> = _events

    private val connectedEndpoints = mutableSetOf<String>()
    private val endpointNames = mutableMapOf<String, String>()
    private val pendingFilePayloads = mutableMapOf<Long, Payload>()
    private var myName = "Device"

    private fun emit(event: NearbyEvent) {
        _events.tryEmit(event)
    }

    fun start(displayName: String) {
        myName = displayName
        startAdvertising()
        startDiscovery()
    }

    private fun startAdvertising() {
        val options = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()
        client.startAdvertising(myName, serviceId, lifecycleCallback, options)
            .addOnSuccessListener { emit(NearbyEvent.Info("Visible as $myName")) }
            .addOnFailureListener { emit(NearbyEvent.Info("Advertise failed: ${it.message}")) }
    }

    private fun startDiscovery() {
        val options = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()
        client.startDiscovery(serviceId, endpointDiscoveryCallback, options)
            .addOnSuccessListener { emit(NearbyEvent.Info("Looking for nearby devices")) }
            .addOnFailureListener { emit(NearbyEvent.Info("Discovery failed: ${it.message}")) }
    }

    fun connect(endpointId: String) {
        client.requestConnection(myName, endpointId, lifecycleCallback)
            .addOnFailureListener { emit(NearbyEvent.Info("Connect failed: ${it.message}")) }
    }

    /** Send a small payload to one endpoint. */
    fun sendBytes(endpointId: String, bytes: ByteArray) {
        client.sendPayload(endpointId, Payload.fromBytes(bytes))
            .addOnFailureListener { emit(NearbyEvent.Info("Send failed: ${it.message}")) }
    }

    /** Send a larger payload from a file to one endpoint. */
    fun sendFile(endpointId: String, file: File) {
        client.sendPayload(endpointId, Payload.fromFile(file))
            .addOnFailureListener { emit(NearbyEvent.Info("Send failed: ${it.message}")) }
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        connectedEndpoints.clear()
        endpointNames.clear()
        pendingFilePayloads.clear()
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            endpointNames[endpointId] = info.endpointName
            emit(NearbyEvent.PeerFound(endpointId, info.endpointName))
        }

        override fun onEndpointLost(endpointId: String) {
            emit(NearbyEvent.PeerLost(endpointId))
        }
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            endpointNames[endpointId] = info.endpointName
            // Both sides receive the same token here — the crypto layer salts with it.
            emit(NearbyEvent.AuthenticationToken(endpointId, info.authenticationToken))
            // Prototype: accept automatically. A real app would confirm first.
            client.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                connectedEndpoints.add(endpointId)
                emit(NearbyEvent.Connected(endpointId, endpointNames[endpointId] ?: endpointId))
            } else {
                emit(NearbyEvent.Info("Connection failed: ${result.status.statusMessage}"))
            }
        }

        override fun onDisconnected(endpointId: String) {
            connectedEndpoints.remove(endpointId)
            emit(NearbyEvent.Disconnected(endpointId))
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> payload.asBytes()?.let {
                    emit(NearbyEvent.PayloadReceived(endpointId, it))
                }

                Payload.Type.FILE -> pendingFilePayloads[payload.id] = payload
                else -> Unit
            }
        }

        override fun onPayloadTransferUpdate(
            endpointId: String,
            update: PayloadTransferUpdate
        ) {
            if (update.status == PayloadTransferUpdate.Status.SUCCESS &&
                update.payloadType == Payload.Type.FILE
            ) {
                val payload = pendingFilePayloads.remove(update.payloadId) ?: return
                val file = payload.asFile()?.asFile() ?: return
                val bytes = runCatching { file.readBytes() }.getOrNull() ?: return
                emit(NearbyEvent.PayloadReceived(endpointId, bytes))
            }
        }
    }
}
