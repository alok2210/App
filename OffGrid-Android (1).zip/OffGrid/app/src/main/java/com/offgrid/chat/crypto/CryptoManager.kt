package com.offgrid.chat.crypto

import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * End-to-end encryption with a per-peer key agreed using ECDH (P-256).
 *
 * Each phone generates one ephemeral EC key pair. When a connection starts, the
 * two sides exchange public keys in the clear and each independently computes
 * the same shared secret. That secret is run through HKDF (salted with the
 * Nearby pairing token, so it is also bound to the pairing) to produce a
 * 256-bit AES key. Nothing secret ever travels over the air.
 *
 * Because the public keys are exchanged in the clear, a man-in-the-middle is
 * possible in principle — which is exactly why both sides also show the same
 * **safety number** (a hash of both public keys and the token). Compare it out
 * loud; if the numbers match, there is no MITM.
 */
class CryptoManager {

    private val keyPair = KeyPairGenerator.getInstance("EC").apply {
        initialize(ECGenParameterSpec("secp256r1"))
    }.generateKeyPair()

    private val random = SecureRandom()
    private val keys = mutableMapOf<String, SecretKey>()
    private val tokens = mutableMapOf<String, String>()
    private val safety = mutableMapOf<String, String>()

    /** Start a session with a peer; returns our public key to send them. */
    fun beginSession(endpointId: String, token: String): ByteArray {
        tokens[endpointId] = token
        return keyPair.public.encoded
    }

    fun isReady(endpointId: String): Boolean = keys.containsKey(endpointId)
    fun safetyNumber(endpointId: String): String? = safety[endpointId]

    /** Finish the handshake with the peer's public key; returns the safety number. */
    fun completeSession(endpointId: String, peerPublicKey: ByteArray): String? {
        return try {
            val keyFactory = KeyFactory.getInstance("EC")
            val peerKey = keyFactory.generatePublic(X509EncodedKeySpec(peerPublicKey))
            val agreement = KeyAgreement.getInstance("ECDH")
            agreement.init(keyPair.private)
            agreement.doPhase(peerKey, true)
            val shared = agreement.generateSecret()

            val token = tokens[endpointId] ?: ""
            val keyBytes = hkdf(
                ikm = shared,
                salt = "offgrid-salt".toByteArray(Charsets.UTF_8),
                info = ("offgrid-ecdh:" + token).toByteArray(Charsets.UTF_8),
                length = 32
            )
            keys[endpointId] = SecretKeySpec(keyBytes, "AES")

            val number = safetyNumberFor(keyPair.public.encoded, peerPublicKey, token)
            safety[endpointId] = number
            number
        } catch (e: Exception) {
            null
        }
    }

    /** Returns IV (12 bytes) + ciphertext + GCM tag, or null if not yet secure. */
    fun encrypt(endpointId: String, plain: ByteArray): ByteArray? {
        val key = keys[endpointId] ?: return null
        val iv = ByteArray(12)
        random.nextBytes(iv)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(plain)
    }

    fun decrypt(endpointId: String, data: ByteArray): ByteArray? {
        val key = keys[endpointId] ?: return null
        if (data.size < 13) return null
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(0, 12)))
            cipher.doFinal(data.copyOfRange(12, data.size))
        } catch (e: Exception) {
            null
        }
    }

    fun clear(endpointId: String) {
        keys.remove(endpointId)
        tokens.remove(endpointId)
        safety.remove(endpointId)
    }

    // --- HKDF-SHA256 (extract + expand) ---

    private fun hkdf(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(salt, "HmacSHA256"))
        val prk = mac.doFinal(ikm)

        val out = ByteArray(length)
        var previous = ByteArray(0)
        var pos = 0
        var counter = 1
        mac.init(SecretKeySpec(prk, "HmacSHA256"))
        while (pos < length) {
            mac.reset()
            mac.update(previous)
            mac.update(info)
            mac.update(counter.toByte())
            previous = mac.doFinal()
            val n = minOf(previous.size, length - pos)
            System.arraycopy(previous, 0, out, pos, n)
            pos += n
            counter++
        }
        return out
    }

    // --- Safety number: a 12-digit fingerprint both sides can compare ---

    private fun safetyNumberFor(a: ByteArray, b: ByteArray, token: String): String {
        val ordered = if (compare(a, b) <= 0) a + b else b + a
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(ordered + token.toByteArray(Charsets.UTF_8))

        var value = 0L
        for (i in 0 until 6) {
            value = (value shl 8) or (digest[i].toLong() and 0xFF)
        }
        value %= 1_000_000_000_000L
        val s = value.toString().padStart(12, '0')
        return "${s.substring(0, 4)} ${s.substring(4, 8)} ${s.substring(8, 12)}"
    }

    private fun compare(a: ByteArray, b: ByteArray): Int {
        val n = minOf(a.size, b.size)
        for (i in 0 until n) {
            val d = (a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)
            if (d != 0) return d
        }
        return a.size - b.size
    }
}
