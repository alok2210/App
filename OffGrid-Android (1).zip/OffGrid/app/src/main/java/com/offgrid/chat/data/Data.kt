package com.offgrid.chat.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** One chat message, stored locally on the device. */
@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uid: String,
    val type: Int,
    val text: String,
    val mediaPath: String?,
    val fileName: String?,
    val senderName: String,
    val isMine: Boolean,
    val peerId: String,
    val replyToUid: String?,
    val replyPreview: String?,
    val expiresAt: Long,     // 0 = never
    val read: Boolean,
    val timestamp: Long
)

/** One emoji reaction on a message. */
@Entity(tableName = "reactions")
data class Reaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val messageUid: String,
    val emoji: String,
    val isMine: Boolean
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    fun observeAll(): Flow<List<Message>>

    @Insert
    suspend fun insert(message: Message)

    @Query("UPDATE messages SET read = 1 WHERE uid = :uid")
    suspend fun markRead(uid: String)

    @Query("UPDATE messages SET expiresAt = :expiresAt WHERE uid = :uid")
    suspend fun setExpiry(uid: String, expiresAt: Long)

    @Query("SELECT * FROM messages WHERE expiresAt > 0 AND expiresAt <= :now")
    suspend fun expired(now: Long): List<Message>

    @Query("DELETE FROM messages WHERE expiresAt > 0 AND expiresAt <= :now")
    suspend fun deleteExpired(now: Long)

    @Query("DELETE FROM messages")
    suspend fun clear()
}

@Dao
interface ReactionDao {
    @Query("SELECT * FROM reactions")
    fun observeAll(): Flow<List<Reaction>>

    @Insert
    suspend fun insert(reaction: Reaction)

    @Query("DELETE FROM reactions")
    suspend fun clear()
}

@Database(
    entities = [Message::class, Reaction::class],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun reactionDao(): ReactionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "offgrid.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
