package com.offgrid.chat.game

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offgrid.chat.data.Message

/**
 * Rock-paper-scissors over the offline channel.
 *
 * Each pick is sent as "RPS:<rock|paper|scissors>"; "RPS:RESET" starts a new
 * round. Both phones derive the round from the same message stream, so they
 * always show the same result.
 */
@Composable
fun RockPaperScissorsDialog(
    messages: List<Message>,
    onSend: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val round = remember(messages) {
        val relevant = messages.filter { it.text.startsWith("RPS:") }
        val lastReset = relevant.indexOfLast { it.text == "RPS:RESET" }
        relevant.drop(lastReset + 1)
    }

    fun choiceOf(mine: Boolean): String? = round
        .lastOrNull { it.isMine == mine && it.text.startsWith("RPS:") && it.text != "RPS:RESET" }
        ?.text?.removePrefix("RPS:")

    val myChoice = choiceOf(true)
    val peerChoice = choiceOf(false)
    val outcome = if (myChoice != null && peerChoice != null) decide(myChoice, peerChoice) else null

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            TextButton(onClick = { onSend("RPS:RESET") }) { Text("New round") }
        },
        title = { Text("Rock · Paper · Scissors") },
        text = {
            Column {
                Text(
                    when {
                        outcome != null -> outcome
                        myChoice != null -> "Waiting for the other player…"
                        else -> "Make your move"
                    }
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoveButton("Rock", myChoice, onSend)
                    MoveButton("Paper", myChoice, onSend)
                    MoveButton("Scissors", myChoice, onSend)
                }
                Spacer(Modifier.height(16.dp))
                Text("You: ${myChoice ?: "—"}")
                Text("Them: ${peerChoice ?: "—"}")
            }
        }
    )
}

@Composable
private fun MoveButton(label: String, myChoice: String?, onSend: (String) -> Unit) {
    Button(
        onClick = { onSend("RPS:${label.lowercase()}") },
        enabled = myChoice == null
    ) { Text(label) }
}

private fun decide(mine: String, theirs: String): String {
    if (mine == theirs) return "It's a draw"
    val wins = (mine == "rock" && theirs == "scissors") ||
        (mine == "paper" && theirs == "rock") ||
        (mine == "scissors" && theirs == "paper")
    return if (wins) "You win" else "You lose"
}
