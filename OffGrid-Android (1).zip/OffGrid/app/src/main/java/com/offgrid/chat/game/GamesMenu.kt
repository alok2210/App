package com.offgrid.chat.game

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Identifiers for the games, used by the chat screen to open the right dialog. */
object GameId {
    const val TIC_TAC_TOE = "ttt"
    const val RPS = "rps"
    const val REACTION = "reaction"
    const val DOODLE = "doodle"
}

@Composable
fun GamesMenu(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("Play a game") },
        text = {
            Column {
                GameChoice("Tic-tac-toe", GameId.TIC_TAC_TOE, onPick)
                GameChoice("Rock · Paper · Scissors", GameId.RPS, onPick)
                GameChoice("Reaction duel", GameId.REACTION, onPick)
                GameChoice("Shared doodle", GameId.DOODLE, onPick)
            }
        }
    )
}

@Composable
private fun GameChoice(label: String, id: String, onPick: (String) -> Unit) {
    OutlinedButton(
        onClick = { onPick(id) },
        modifier = Modifier.fillMaxWidth().height(48.dp)
    ) { Text(label) }
    Spacer(Modifier.height(8.dp))
}
