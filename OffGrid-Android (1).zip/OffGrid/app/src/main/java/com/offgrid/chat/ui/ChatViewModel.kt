package com.offgrid.chat.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.offgrid.chat.crypto.CryptoManager
import com.offgrid.chat.data.AppDatabase
import com.offgrid.chat.data.ControlAction
import com.offgrid.chat.data.Envelope
import com.offgrid.chat.data.Message
import com.offgrid.chat.data.MessageCodec
import com.offgrid.chat.data.MessageType
import com.offgrid.chat.data.Reaction
import com.offgrid.chat.data.WireMessage
import com.offgrid.chat.media.MediaUtil
import com.offgrid.chat.nearby.NearbyEvent
import com.offgrid.chat.nearby.NearbyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Peer(val endpointId: String, val name: String)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    private val nearby = NearbyManager(app)
    private val crypto = CryptoManager()

    /** Above this size a payload is sent as a file rather than as bytes. */
    private val fileThreshold = 600_000

    private val displayNames = mutableMapOf<String, String>()
    private val tokens = mutableMapOf<String, String>()

    private val _myName = MutableStateFlow("OffGrid-" + UUID.randomUUID().toString().take(4))
    val myName: StateFlow<String> = _myName

    private val _disappearing = MutableStateFlow(0)
    val disappearing: StateFlow<Int> = _disappearing

    val messages: StateFlow<List<Message>> =
        db.messageDao().observeAll().stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
        )

    val reactions: StateFlow<List<Reaction>> =
        db.reactionDao().observeAll().stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
        )

    private val _peers = MutableStateFlow<List<Peer>>(emptyList())
    val peers: StateFlow<List<Peer>> = _peers

    private val _connections = MutableStateFlow<List<Peer>>(emptyList())
    val connections: StateFlow<List<Peer>> = _connections

    private val _status = MutableStateFlow("Idle")
    val status: StateFlow<String> = _status

    private val _safety = MutableStateFlow<Map<String, String>>(emptyMap())
    val safety: StateFlow<Map<String, String>> = _safety

    private val _typing = MutableStateFlow<Set<String>>(emptySet())
    val typing: StateFlow<Set<String>> = _typing

    /** uid of messages the user has revealed (opened snaps). */
    private val _revealed = MutableStateFlow<Set<String>>(emptySet())
    val revealed: StateFlow<Set<String>> = _revealed

    /** Transient notice, e.g. "Peer took a screenshot". */
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice

    private val typingSeen = mutableMapOf<String, Long>()
    private var lastTypingSent = 0L

    init {
        viewModelScope.launch { nearby.events.collect { handleEvent(it) } }
        viewModelScope.launch { ticker() }
    }

    fun start() {
        nearby.start(_myName.value)
        _status.value = "Visible as ${_myName.value}"
    }

    // ---- public actions -----------------------------------------------------

    fun setMyName(name: String) {
        val clean = name.trim().ifBlank { return }
        _myName.value = clean
        sendControl(JSONObject().put("action", ControlAction.NAME).put("name", clean).toString())
    }

    fun setDisappearing(seconds: Int) {
        _disappearing.value = seconds
    }

    fun connect(peer: Peer) = nearby.connect(peer.endpointId)

    fun send(text: String, replyTo: Message? = null) {
        if (text.isBlank()) return
        val ttl = _disappearing.value
        viewModelScope.launch {
            val uid = MessageCodec.newUid()
            val expires = expiresFor(ttl)
            store(
                Message(
                    uid = uid, type = MessageType.TEXT, text = text, mediaPath = null, fileName = null,
                    senderName = _myName.value, isMine = true, peerId = "",
                    replyToUid = replyTo?.uid, replyPreview = previewOf(replyTo),
                    expiresAt = expires, read = false, timestamp = System.currentTimeMillis()
                )
            )
            broadcast(
                MessageCodec.text(
                    uid, _myName.value, text, replyTo?.uid, previewOf(replyTo), ttl
                )
            )
        }
    }

    fun sendImage(uri: Uri) {
        viewModelScope.launch {
            val bytes = withContext(Dispatchers.IO) {
                runCatching { MediaUtil.downscaleJpeg(getApplication(), uri) }.getOrNull()
            } ?: return@launch
            val path = withContext(Dispatchers.IO) {
                MediaUtil.saveToFiles(getApplication(), bytes, "jpg")
            }
            sendMedia(MessageType.IMAGE, bytes, path, null)
        }
    }

    fun sendAudio(path: String) {
        viewModelScope.launch {
            val bytes = withContext(Dispatchers.IO) {
                runCatching { File(path).readBytes() }.getOrNull()
            } ?: return@launch
            sendMedia(MessageType.AUDIO, bytes, path, null)
        }
    }

    fun sendVideo(uri: Uri) {
        viewModelScope.launch {
            val (path, name) = withContext(Dispatchers.IO) {
                runCatching { MediaUtil.importFile(getApplication(), uri, "mp4") }.getOrNull()
            } ?: return@launch
            val bytes = withContext(Dispatchers.IO) {
                runCatching { File(path).readBytes() }.getOrNull()
            } ?: return@launch
            sendMedia(MessageType.VIDEO, bytes, path, name)
        }
    }

    fun sendFile(uri: Uri) {
        viewModelScope.launch {
            val (path, name) = withContext(Dispatchers.IO) {
                runCatching { MediaUtil.importFile(getApplication(), uri, "bin") }.getOrNull()
            } ?: return@launch
            val bytes = withContext(Dispatchers.IO) {
                runCatching { File(path).readBytes() }.getOrNull()
            } ?: return@launch
            sendMedia(MessageType.FILE, bytes, path, name)
        }
    }

    private suspend fun sendMedia(type: Int, bytes: ByteArray, path: String, fileName: String?) {
        val ttl = _disappearing.value
        val uid = MessageCodec.newUid()
        store(
            Message(
                uid = uid, type = type, text = "", mediaPath = path, fileName = fileName,
                senderName = _myName.value, isMine = true, peerId = "",
                replyToUid = null, replyPreview = null,
                expiresAt = expiresFor(ttl), read = false, timestamp = System.currentTimeMillis()
            )
        )
        broadcast(MessageCodec.media(type, uid, _myName.value, fileName, ttl, bytes))
    }

    fun onTyping() {
        val now = System.currentTimeMillis()
        if (now - lastTypingSent < 1_500) return
        lastTypingSent = now
        sendControl(JSONObject().put("action", ControlAction.TYPING).toString())
    }

    /** Mark a received message as read and tell the sender. */
    fun markRead(message: Message) {
        if (message.isMine || message.read) return
        viewModelScope.launch {
            db.messageDao().markRead(message.uid)
            sendControl(JSONObject().put("action", ControlAction.READ).put("uid", message.uid).toString())
        }
    }

    fun react(message: Message, emoji: String) {
        viewModelScope.launch {
            db.reactionDao().insert(Reaction(messageUid = message.uid, emoji = emoji, isMine = true))
            sendControl(
                JSONObject().put("action", ControlAction.REACT)
                    .put("uid", message.uid).put("emoji", emoji).toString()
            )
        }
    }

    /** Reveal an image snap; starts the countdown on both phones. */
    fun openSnap(message: Message) {
        val ttl = 10
        _revealed.value = _revealed.value + message.uid
        viewModelScope.launch {
            val expires = System.currentTimeMillis() + ttl * 1000L
            db.messageDao().setExpiry(message.uid, expires)
            sendControl(
                JSONObject().put("action", ControlAction.SNAP_OPEN)
                    .put("uid", message.uid).put("ttl", ttl).toString()
            )
        }
    }

    fun notifyLocalScreenshot() {
        _notice.value = "You took a screenshot"
        sendControl(JSONObject().put("action", ControlAction.SCREENSHOT).toString())
    }

    fun dismissNotice() {
        _notice.value = null
    }

    fun clearChat() {
        viewModelScope.launch {
            db.messageDao().clear()
            db.reactionDao().clear()
        }
    }

    /** Write the conversation to a text file; returns its path. */
    suspend fun exportChat(): String? = withContext(Dispatchers.IO) {
        val lines = messages.value.joinToString("\n") { m ->
            val who = if (m.isMine) _myName.value else m.senderName
            val what = when (m.type) {
                MessageType.TEXT -> m.text
                MessageType.IMAGE -> "[photo]"
                MessageType.AUDIO -> "[voice note]"
                MessageType.VIDEO -> "[video]"
                else -> "[file ${m.fileName ?: ""}]"
            }
            "$who: $what"
        }
        runCatching {
            val file = File(getApplication<Application>().filesDir, "offgrid_chat.txt")
            file.writeText(lines)
            file.absolutePath
        }.getOrNull()
    }

    // ---- event handling -----------------------------------------------------

    private fun handleEvent(event: NearbyEvent) {
        when (event) {
            is NearbyEvent.Info -> _status.value = event.message
            is NearbyEvent.AuthenticationToken -> tokens[event.endpointId] = event.token
            is NearbyEvent.PeerFound -> {
                _peers.value = (_peers.value + Peer(event.endpointId, event.name))
                    .distinctBy { it.endpointId }
            }
            is NearbyEvent.PeerLost -> {
                _peers.value = _peers.value.filterNot { it.endpointId == event.endpointId }
            }
            is NearbyEvent.Connected -> onConnected(event)
            is NearbyEvent.Disconnected -> {
                _connections.value = _connections.value.filterNot { it.endpointId == event.endpointId }
                _safety.value = _safety.value - event.endpointId
                displayNames.remove(event.endpointId)
                tokens.remove(event.endpointId)
                crypto.clear(event.endpointId)
                _status.value = "Disconnected"
            }
            is NearbyEvent.PayloadReceived -> viewModelScope.launch { onPayload(event) }
        }
    }

    private fun onConnected(event: NearbyEvent.Connected) {
        displayNames[event.endpointId] = event.name
        _connections.value = (_connections.value + Peer(event.endpointId, event.name))
            .distinctBy { it.endpointId }
        _status.value = "Connected to ${event.name}"

        val token = tokens[event.endpointId]
        if (token != null) {
            val publicKey = crypto.beginSession(event.endpointId, token)
            nearby.sendBytes(event.endpointId, Envelope.handshake(_myName.value, publicKey))
        }
    }

    private suspend fun onPayload(event: NearbyEvent.PayloadReceived) {
        val data = event.bytes
        when (Envelope.kindOf(data)) {
            Envelope.KIND_CONTROL -> {
                if (Envelope.isHandshake(data)) {
                    val peerName = Envelope.handshakeName(data)
                    rename(event.endpointId, peerName)
                    val number = crypto.completeSession(event.endpointId, Envelope.handshakeKey(data))
                    if (number != null) {
                        _safety.value = _safety.value + (event.endpointId to number)
                        _status.value = "Secured with $peerName"
                    }
                }
            }

            Envelope.KIND_ENCRYPTED -> {
                val plain = crypto.decrypt(event.endpointId, Envelope.encryptedBody(data)) ?: return
                val wire = MessageCodec.decode(plain) ?: return
                deliver(event.endpointId, wire)
            }

            else -> Unit
        }
    }

    private suspend fun deliver(endpointId: String, wire: WireMessage) {
        rename(endpointId, wire.senderName)

        if (wire.type == MessageType.CONTROL) {
            handleControl(endpointId, wire)
            return
        }

        val extension = when (wire.type) {
            MessageType.IMAGE -> "jpg"
            MessageType.AUDIO -> "m4a"
            MessageType.VIDEO -> "mp4"
            else -> "bin"
        }
        val path = if (wire.type == MessageType.TEXT) null else withContext(Dispatchers.IO) {
            MediaUtil.saveToFiles(getApplication(), wire.body, extension)
        }

        store(
            Message(
                uid = wire.uid,
                type = wire.type,
                text = if (wire.type == MessageType.TEXT) String(wire.body, Charsets.UTF_8) else "",
                mediaPath = path,
                fileName = wire.fileName,
                senderName = wire.senderName,
                isMine = false,
                peerId = endpointId,
                replyToUid = wire.replyToUid,
                replyPreview = wire.replyPreview,
                expiresAt = expiresFor(wire.ttlSeconds),
                read = false,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    private fun handleControl(endpointId: String, wire: WireMessage) {
        val json = runCatching { JSONObject(String(wire.body, Charsets.UTF_8)) }.getOrNull() ?: return
        when (json.optString("action")) {
            ControlAction.TYPING -> {
                typingSeen[displayNames[endpointId] ?: "Peer"] = System.currentTimeMillis()
            }
            ControlAction.READ -> {
                val uid = json.optString("uid")
                if (uid.isNotEmpty()) viewModelScope.launch { db.messageDao().markRead(uid) }
            }
            ControlAction.REACT -> {
                val uid = json.optString("uid")
                val emoji = json.optString("emoji")
                if (uid.isNotEmpty() && emoji.isNotEmpty()) {
                    viewModelScope.launch {
                        db.reactionDao().insert(Reaction(messageUid = uid, emoji = emoji, isMine = false))
                    }
                }
            }
            ControlAction.NAME -> {
                rename(endpointId, json.optString("name"))
            }
            ControlAction.SCREENSHOT -> {
                _notice.value = "${displayNames[endpointId] ?: "Peer"} took a screenshot"
            }
            ControlAction.SNAP_OPEN -> {
                val uid = json.optString("uid")
                val ttl = json.optInt("ttl", 10)
                if (uid.isNotEmpty()) {
                    viewModelScope.launch { db.messageDao().setExpiry(uid, System.currentTimeMillis() + ttl * 1000L) }
                }
            }
        }
    }

    private fun rename(endpointId: String, name: String) {
        if (name.isBlank()) return
        displayNames[endpointId] = name
        _connections.value = _connections.value.map {
            if (it.endpointId == endpointId) Peer(endpointId, name) else it
        }
    }

    // ---- helpers ------------------------------------------------------------

    private suspend fun store(message: Message) = db.messageDao().insert(message)

    private fun expiresFor(ttlSeconds: Int): Long =
        if (ttlSeconds > 0) System.currentTimeMillis() + ttlSeconds * 1000L else 0L

    private fun previewOf(message: Message?): String? = message?.let {
        when (it.type) {
            MessageType.TEXT -> it.text.take(60)
            MessageType.IMAGE -> "Photo"
            MessageType.AUDIO -> "Voice note"
            MessageType.VIDEO -> "Video"
            else -> it.fileName ?: "File"
        }
    }

    private fun sendControl(json: String) {
        val wire = MessageCodec.control(_myName.value, json)
        viewModelScope.launch { broadcast(wire) }
    }

    private suspend fun broadcast(wire: WireMessage) {
        val inner = MessageCodec.encode(wire)
        for (peer in _connections.value) {
            val cipher = crypto.encrypt(peer.endpointId, inner) ?: continue
            val envelope = Envelope.encrypted(cipher)
            if (envelope.size > fileThreshold) {
                val temp = withContext(Dispatchers.IO) {
                    File(getApplication<Application>().cacheDir, "out_${System.nanoTime()}.bin")
                        .also { it.writeBytes(envelope) }
                }
                nearby.sendFile(peer.endpointId, temp)
            } else {
                nearby.sendBytes(peer.endpointId, envelope)
            }
        }
    }

    /** Once a second: refresh the typing set; every few ticks, drop expired messages. */
    private suspend fun ticker() {
        var ticks = 0
        while (true) {
            delay(1_000)
            ticks++
            val now = System.currentTimeMillis()
            _typing.value = typingSeen.filterValues { now - it < 3_000 }.keys
            if (ticks % 3 == 0) cleanupExpired(now)
        }
    }

    private suspend fun cleanupExpired(now: Long) {
        val expired = db.messageDao().expired(now)
        if (expired.isEmpty()) return
        withContext(Dispatchers.IO) {
            expired.forEach { m -> m.mediaPath?.let { runCatching { File(it).delete() } } }
        }
        db.messageDao().deleteExpired(now)
    }

    override fun onCleared() {
        nearby.stop()
        super.onCleared()
    }
}
