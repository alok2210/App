package com.offgrid.chat.data

import org.json.JSONObject
import java.nio.ByteBuffer
import java.util.UUID

/** Kinds of message carried inside an encrypted frame. */
object MessageType {
    const val TEXT = 0
    const val IMAGE = 1
    const val AUDIO = 2
    const val VIDEO = 3
    const val FILE = 4
    const val CONTROL = 5   // never stored; typing / read / react / rename / screenshot
}

/** Ephemeral control actions, carried in a CONTROL message body as JSON. */
object ControlAction {
    const val TYPING = "typing"
    const val READ = "read"
    const val REACT = "react"
    const val NAME = "name"
    const val SCREENSHOT = "screenshot"
    const val SNAP_OPEN = "snapopen"
}

/**
 * A decoded message. The header is small and extensible: a type byte, the
 * message's shared id (uid), and a JSON metadata blob (sender name, reply info,
 * time-to-live, file name). The body is the raw payload (text, JPEG, audio…).
 */
data class WireMessage(
    val type: Int,
    val uid: String,
    val senderName: String,
    val replyToUid: String?,
    val replyPreview: String?,
    val ttlSeconds: Int,
    val fileName: String?,
    val body: ByteArray
)

object MessageCodec {

    fun newUid(): String = UUID.randomUUID().toString()

    fun text(uid: String, senderName: String, text: String, replyToUid: String?, replyPreview: String?, ttl: Int) =
        WireMessage(MessageType.TEXT, uid, senderName, replyToUid, replyPreview, ttl, null, text.toByteArray(Charsets.UTF_8))

    fun media(type: Int, uid: String, senderName: String, fileName: String?, ttl: Int, body: ByteArray) =
        WireMessage(type, uid, senderName, null, null, ttl, fileName, body)

    fun control(senderName: String, json: String) =
        WireMessage(MessageType.CONTROL, newUid(), senderName, null, null, 0, null, json.toByteArray(Charsets.UTF_8))

    fun encode(w: WireMessage): ByteArray {
        val uid = w.uid.toByteArray(Charsets.UTF_8)
        val meta = JSONObject().apply {
            put("name", w.senderName)
            w.replyToUid?.let { put("replyUid", it) }
            w.replyPreview?.let { put("replyPreview", it) }
            put("ttl", w.ttlSeconds)
            w.fileName?.let { put("fileName", it) }
        }.toString().toByteArray(Charsets.UTF_8)

        val buffer = ByteBuffer.allocate(1 + 2 + uid.size + 2 + meta.size + w.body.size)
        buffer.put(w.type.toByte())
        buffer.putShort(uid.size.toShort()); buffer.put(uid)
        buffer.putShort(meta.size.toShort()); buffer.put(meta)
        buffer.put(w.body)
        return buffer.array()
    }

    fun decode(data: ByteArray): WireMessage? {
        return try {
            val buffer = ByteBuffer.wrap(data)
            val type = buffer.get().toInt()
            val uid = ByteArray(buffer.short.toInt()).also { buffer.get(it) }.toString(Charsets.UTF_8)
            val meta = JSONObject(String(ByteArray(buffer.short.toInt()).also { buffer.get(it) }, Charsets.UTF_8))
            val body = ByteArray(buffer.remaining()).also { buffer.get(it) }
            WireMessage(
                type = type,
                uid = uid,
                senderName = meta.optString("name", "Peer"),
                replyToUid = if (meta.has("replyUid")) meta.getString("replyUid") else null,
                replyPreview = if (meta.has("replyPreview")) meta.getString("replyPreview") else null,
                ttlSeconds = meta.optInt("ttl", 0),
                fileName = if (meta.has("fileName")) meta.getString("fileName") else null,
                body = body
            )
        } catch (e: Exception) {
            null
        }
    }
}

/**
 * The outer envelope that actually travels on the radio:
 *
 *   KIND_CONTROL   : plaintext. byte 1 = control type, then the body.
 *   KIND_ENCRYPTED : the AES-GCM output (IV + ciphertext + tag).
 *
 * The only plaintext control is the handshake, which carries the sender's name
 * and ECDH public key. Everything else is encrypted.
 */
object Envelope {

    const val KIND_CONTROL = 0
    const val KIND_ENCRYPTED = 1
    const val CONTROL_HANDSHAKE = 0

    fun handshake(name: String, publicKey: ByteArray): ByteArray {
        val n = name.toByteArray(Charsets.UTF_8)
        val buffer = ByteBuffer.allocate(2 + 2 + n.size + 2 + publicKey.size)
        buffer.put(KIND_CONTROL.toByte()); buffer.put(CONTROL_HANDSHAKE.toByte())
        buffer.putShort(n.size.toShort()); buffer.put(n)
        buffer.putShort(publicKey.size.toShort()); buffer.put(publicKey)
        return buffer.array()
    }

    fun encrypted(cipher: ByteArray): ByteArray =
        byteArrayOf(KIND_ENCRYPTED.toByte()) + cipher

    fun kindOf(data: ByteArray): Int? = if (data.isEmpty()) null else data[0].toInt()

    fun isHandshake(data: ByteArray): Boolean =
        data.size >= 2 && data[0].toInt() == KIND_CONTROL && data[1].toInt() == CONTROL_HANDSHAKE

    fun handshakeName(data: ByteArray): String {
        val buffer = ByteBuffer.wrap(data, 2, data.size - 2)
        val nameLen = buffer.short.toInt()
        return ByteArray(nameLen).also { buffer.get(it) }.toString(Charsets.UTF_8)
    }

    fun handshakeKey(data: ByteArray): ByteArray {
        val buffer = ByteBuffer.wrap(data, 2, data.size - 2)
        val nameLen = buffer.short.toInt()
        buffer.position(buffer.position() + nameLen)
        val keyLen = buffer.short.toInt()
        return ByteArray(keyLen).also { buffer.get(it) }
    }

    fun encryptedBody(data: ByteArray): ByteArray =
        if (data.size > 1) data.copyOfRange(1, data.size) else ByteArray(0)
}
