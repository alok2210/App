package com.offgrid.chat.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.offgrid.chat.data.Message

private val PALETTE = listOf(
    0xFF000000.toInt(), 0xFFE53935.toInt(), 0xFF1E88E5.toInt(),
    0xFF43A047.toInt(), 0xFFFDD835.toInt()
)

private data class DoodleStroke(val color: Int, val points: List<Offset>)

/**
 * A shared drawing pad: both phones draw on the same canvas.
 *
 * Each finished stroke is sent as "DRAW:<color>:<x,y;x,y;…>" with coordinates
 * normalised to 0..1, so the picture looks the same on any screen size.
 * "DRAWCLEAR" wipes the pad for both.
 */
@Composable
fun DoodleDialog(
    messages: List<Message>,
    onSend: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val strokes = remember(messages) { messages.mapNotNull { parseStroke(it.text) } }
    val current = remember { mutableStateListOf<Offset>() }
    var color by remember { mutableStateOf(PALETTE[0]) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = { TextButton(onClick = { onSend("DRAWCLEAR") }) { Text("Clear") } },
        title = { Text("Shared doodle") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PALETTE.forEach { c ->
                        Box(
                            Modifier
                                .size(28.dp)
                                .padding(2.dp)
                                .background(Color(c), CircleShape)
                                .clickable { color = c }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(Color.White)
                        .onSizeChanged { canvasSize = it }
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        current.clear()
                                        current.add(offset)
                                    },
                                    onDrag = { change, _ -> current.add(change.position) },
                                    onDragEnd = {
                                        if (current.size > 1 && canvasSize.width > 0 && canvasSize.height > 0) {
                                            val norm = current.map {
                                                Offset(it.x / canvasSize.width, it.y / canvasSize.height)
                                            }
                                            val payload = norm.joinToString(";") { "${it.x},${it.y}" }
                                            onSend("DRAW:$color:$payload")
                                        }
                                        current.clear()
                                    }
                                )
                            }
                    ) {
                        strokes.forEach { drawNormalized(it) }
                        if (current.size > 1) {
                            val path = Path()
                            path.moveTo(current[0].x, current[0].y)
                            for (i in 1 until current.size) path.lineTo(current[i].x, current[i].y)
                            drawPath(
                                path, Color(color),
                                style = Stroke(6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Both of you draw on the same pad.", style = MaterialTheme.typography.bodySmall)
            }
        }
    )
}

private fun DrawScope.drawNormalized(stroke: DoodleStroke) {
    if (stroke.points.size < 2) return
    val path = Path()
    val first = Offset(stroke.points[0].x * size.width, stroke.points[0].y * size.height)
    path.moveTo(first.x, first.y)
    for (i in 1 until stroke.points.size) {
        val p = Offset(stroke.points[i].x * size.width, stroke.points[i].y * size.height)
        path.lineTo(p.x, p.y)
    }
    drawPath(
        path, Color(stroke.color),
        style = Stroke(6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun parseStroke(text: String): DoodleStroke? {
    if (!text.startsWith("DRAW:")) return null
    val parts = text.split(":", limit = 3)
    if (parts.size != 3) return null
    val color = parts[1].toIntOrNull() ?: return null
    val points = parts[2].split(";").mapNotNull { pair ->
        val xy = pair.split(",")
        if (xy.size == 2) {
            val x = xy[0].toFloatOrNull()
            val y = xy[1].toFloatOrNull()
            if (x != null && y != null) Offset(x, y) else null
        } else null
    }
    if (points.size < 2) return null
    return DoodleStroke(color, points)
}
