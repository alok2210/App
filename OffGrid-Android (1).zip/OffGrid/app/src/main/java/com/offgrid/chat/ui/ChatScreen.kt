package com.offgrid.chat.ui

import android.Manifest
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Vibrator
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.offgrid.chat.R
import com.offgrid.chat.data.Message
import com.offgrid.chat.data.MessageType
import com.offgrid.chat.data.Reaction
import com.offgrid.chat.game.DoodleDialog
import com.offgrid.chat.game.GameId
import com.offgrid.chat.game.GamesMenu
import com.offgrid.chat.game.ReactionDuelDialog
import com.offgrid.chat.game.RockPaperScissorsDialog
import com.offgrid.chat.game.TicTacToeDialog
import com.offgrid.chat.media.AudioPlayer
import com.offgrid.chat.media.AudioRecorder
import com.offgrid.chat.media.MediaUtil
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val REACTION_CHOICES = listOf("\u2764\uFE0F", "\uD83D\uDE02", "\uD83D\uDC4D", "\uD83D\uDE2E", "\uD83D\uDE22")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(
    vm: ChatViewModel,
    requestPermissions: () -> Unit,
    darkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val reactions by vm.reactions.collectAsStateWithLifecycle()
    val peers by vm.peers.collectAsStateWithLifecycle()
    val connections by vm.connections.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val safety by vm.safety.collectAsStateWithLifecycle()
    val typing by vm.typing.collectAsStateWithLifecycle()
    val revealed by vm.revealed.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val myName by vm.myName.collectAsStateWithLifecycle()
    val disappearing by vm.disappearing.collectAsStateWithLifecycle()

    var input by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<Message?>(null) }
    var actionTarget by remember { mutableStateOf<Message?>(null) }
    var showGames by remember { mutableStateOf(false) }
    var showAttach by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showTimer by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var openGame by remember { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }

    val recorder = remember { AudioRecorder(context) }
    val listState = rememberLazyListState()

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        it?.let { uri -> vm.sendImage(uri) }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        it?.let { uri -> vm.sendFile(uri) }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { vm.sendImage(it) }
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        if (ok) pendingUri?.let { vm.sendVideo(it) }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it && recorder.start()) recording = true
    }

    LaunchedEffect(Unit) {
        requestPermissions()
        vm.start()
    }

    // Auto-scroll to the newest message.
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("OffGrid Chat", fontWeight = FontWeight.Bold)
                        Text(status, style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    TextButton(onClick = { searching = !searching }) { Text("Find") }
                    TextButton(onClick = { showSettings = true }) { Text("Menu") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
            if (searching) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search messages") }
                )
                Spacer(Modifier.height(8.dp))
            }

            notice?.let { text ->
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Row(
                        Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text, style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = vm::dismissNotice) { Text("OK") }
                    }
                }
            }

            if (connections.isEmpty()) {
                NearbyList(peers = peers, onConnect = vm::connect)
            } else {
                ConnectedHeader(connections, safety, onGames = { showGames = true })
                Spacer(Modifier.height(8.dp))

                val visible = messages
                    .filterNot { isGameMessage(it.text) }
                    .filter { query.isBlank() || it.text.contains(query, ignoreCase = true) }

                LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(visible, key = { it.uid }) { msg ->
                        LaunchedEffect(msg.uid) { vm.markRead(msg) }
                        MessageRow(
                            msg = msg,
                            showSender = connections.size > 1,
                            reactions = reactions,
                            revealed = revealed.contains(msg.uid),
                            onOpenSnap = { vm.openSnap(msg) },
                            onLongPress = { actionTarget = msg }
                        )
                    }
                }

                typingText(typing).let { line ->
                    if (line != null) Text(line, style = MaterialTheme.typography.labelSmall)
                }

                replyTo?.let { target ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Replying: ${previewOf(target)}", style = MaterialTheme.typography.labelSmall)
                        TextButton(onClick = { replyTo = null }) { Text("Cancel") }
                    }
                }

                Composer(
                    input = input,
                    onInput = { input = it; vm.onTyping() },
                    disappearing = disappearing,
                    recording = recording,
                    onAttach = { showAttach = true },
                    onTimer = { showTimer = true },
                    onRec = {
                        if (recording) {
                            val file = recorder.stop()
                            recording = false
                            file?.let { vm.sendAudio(it.absolutePath) }
                        } else {
                            micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onSend = {
                        vm.send(input, replyTo)
                        input = ""
                        replyTo = null
                    }
                )
            }
        }
    }

    // ---- dialogs ----

    if (showGames) {
        GamesMenu(onPick = { openGame = it; showGames = false }, onDismiss = { showGames = false })
    }

    if (showAttach) {
        AlertDialog(
            onDismissRequest = { showAttach = false },
            confirmButton = { TextButton(onClick = { showAttach = false }) { Text("Cancel") } },
            title = { Text("Attach") },
            text = {
                Column {
                    AttachOption("Photo from gallery") { showAttach = false; imagePicker.launch("image/*") }
                    AttachOption("Take a photo") {
                        showAttach = false
                        pendingUri = newCacheUri(context, "jpg")
                        cameraLauncher.launch(pendingUri!!)
                    }
                    AttachOption("Record a video") {
                        showAttach = false
                        pendingUri = newCacheUri(context, "mp4")
                        videoLauncher.launch(pendingUri!!)
                    }
                    AttachOption("Send a file") { showAttach = false; filePicker.launch(arrayOf("*/*")) }
                }
            }
        )
    }

    if (showTimer) {
        AlertDialog(
            onDismissRequest = { showTimer = false },
            confirmButton = { TextButton(onClick = { showTimer = false }) { Text("Done") } },
            title = { Text("Disappearing messages") },
            text = {
                Column {
                    Text("Messages vanish from both phones after the chosen time.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    listOf(0 to "Off", 10 to "10 seconds", 60 to "1 minute", 3600 to "1 hour").forEach { (secs, label) ->
                        AttachOption(if (disappearing == secs) "$label  (current)" else label) {
                            vm.setDisappearing(secs); showTimer = false
                        }
                    }
                }
            }
        )
    }

    if (showRename) {
        var name by remember { mutableStateOf(myName) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            confirmButton = { TextButton(onClick = { vm.setMyName(name); showRename = false }) { Text("Save") } },
            title = { Text("Your name") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Close") } },
            title = { Text("Menu") },
            text = {
                Column {
                    Text("You are $myName", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.developed_by),
                        style = MaterialTheme.typography.labelSmall
                    )
                    Spacer(Modifier.height(8.dp))
                    AttachOption("Change my name") { showSettings = false; showRename = true }
                    AttachOption(if (darkTheme) "Switch to light theme" else "Switch to dark theme") {
                        showSettings = false; onToggleTheme()
                    }
                    AttachOption("Ping (buzz)") { showSettings = false; buzz(context) }
                    AttachOption("Export chat") {
                        showSettings = false
                        scope.launch {
                            vm.exportChat()?.let { MediaUtil.openFile(context, it, "offgrid_chat.txt") }
                        }
                    }
                    AttachOption("Clear chat") { showSettings = false; vm.clearChat() }
                }
            }
        )
    }

    actionTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { actionTarget = null },
            confirmButton = { TextButton(onClick = { actionTarget = null }) { Text("Close") } },
            title = { Text("Message") },
            text = {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        REACTION_CHOICES.forEach { emoji ->
                            TextButton(onClick = { vm.react(target, emoji); actionTarget = null }) { Text(emoji) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    AttachOption("Reply") { replyTo = target; actionTarget = null }
                    AttachOption("Copy text") {
                        if (target.text.isNotBlank()) {
                            val clipboard = context.getSystemService(android.content.ClipboardManager::class.java)
                            clipboard?.setPrimaryClip(
                                android.content.ClipData.newPlainText("message", target.text)
                            )
                        }
                        actionTarget = null
                    }
                }
            }
        )
    }

    val peerName = connections.firstOrNull()?.name ?: "Peer"
    when (openGame) {
        GameId.TIC_TAC_TOE -> TicTacToeDialog(myName, peerName, messages, { vm.send(it) }) { openGame = null }
        GameId.RPS -> RockPaperScissorsDialog(messages, { vm.send(it) }) { openGame = null }
        GameId.REACTION -> ReactionDuelDialog(messages, { vm.send(it) }) { openGame = null }
        GameId.DOODLE -> DoodleDialog(messages, { vm.send(it) }) { openGame = null }
        else -> Unit
    }
}

@Composable
private fun ConnectedHeader(
    connections: List<Peer>,
    safety: Map<String, String>,
    onGames: () -> Unit
) {
    val single = connections.size == 1
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                if (single) "Connected: ${connections[0].name}" else "Group: ${connections.size} people",
                fontWeight = FontWeight.SemiBold
            )
            if (single) {
                val number = safety[connections[0].endpointId]
                Text(
                    if (number != null) "Safety: $number" else "Securing…",
                    style = MaterialTheme.typography.labelSmall
                )
            } else {
                val secured = connections.all { safety.containsKey(it.endpointId) }
                Text(if (secured) "Encrypted with everyone" else "Securing…", style = MaterialTheme.typography.labelSmall)
            }
        }
        OutlinedButton(onClick = onGames, enabled = single) { Text("Games") }
    }
}

@Composable
private fun Composer(
    input: String,
    onInput: (String) -> Unit,
    disappearing: Int,
    recording: Boolean,
    onAttach: () -> Unit,
    onTimer: () -> Unit,
    onRec: () -> Unit,
    onSend: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onAttach) { Text("+") }
        TextButton(onClick = onRec) { Text(if (recording) "Stop" else "Rec") }
        OutlinedTextField(
            value = input,
            onValueChange = onInput,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Message") }
        )
        Spacer(Modifier.width(4.dp))
        TextButton(onClick = onTimer) { Text(if (disappearing == 0) "Timer" else "${disappearing}s") }
        Button(onClick = onSend) { Text("Send") }
    }
}

@Composable
private fun AttachOption(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth().height(46.dp)) { Text(label) }
    Spacer(Modifier.height(8.dp))
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageRow(
    msg: Message,
    showSender: Boolean,
    reactions: List<Reaction>,
    revealed: Boolean,
    onOpenSnap: () -> Unit,
    onLongPress: () -> Unit
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalAlignment = if (msg.isMine) Alignment.End else Alignment.Start
    ) {
        if (showSender && !msg.isMine) {
            Text(msg.senderName, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 6.dp))
        }
        msg.replyPreview?.let {
            Text("↩ $it", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 6.dp, bottom = 2.dp))
        }
        Surface(
            color = if (msg.isMine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.combinedClickable(onClick = {}, onLongClick = onLongPress)
        ) {
            Box(Modifier.padding(2.dp)) {
                when (msg.type) {
                    MessageType.IMAGE ->
                        if (!msg.isMine && msg.expiresAt > 0 && !revealed) {
                            TextButton(onClick = onOpenSnap) { Text("Tap to view photo") }
                        } else {
                            ImageBubble(msg.mediaPath)
                        }
                    MessageType.AUDIO -> MediaButton("Play voice note") { msg.mediaPath?.let { AudioPlayer.play(it) } }
                    MessageType.VIDEO -> MediaButton("Play video") {
                        msg.mediaPath?.let { MediaUtil.openFile(context, it, msg.fileName) }
                    }
                    MessageType.FILE -> MediaButton("Open ${msg.fileName ?: "file"}") {
                        msg.mediaPath?.let { MediaUtil.openFile(context, it, msg.fileName) }
                    }
                    else -> Text(msg.text, modifier = Modifier.padding(10.dp))
                }
            }
        }
        val summary = reactionSummary(reactions, msg.uid)
        if (summary.isNotEmpty()) {
            Text(summary, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 6.dp, top = 1.dp))
        }
        Text(
            buildString {
                append(formatTime(msg.timestamp))
                if (msg.isMine) append(if (msg.read) "  ✓✓" else "  ✓")
                if (msg.expiresAt > 0) append("  timer")
            },
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 6.dp)
        )
    }
}

@Composable
private fun MediaButton(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(label) }
}

@Composable
private fun ImageBubble(path: String?) {
    val bitmap = remember(path) { path?.let { BitmapFactory.decodeFile(it) } }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier.height(180.dp).padding(4.dp)
        )
    } else {
        Text("Image", modifier = Modifier.padding(10.dp))
    }
}

@Composable
private fun NearbyList(peers: List<Peer>, onConnect: (Peer) -> Unit) {
    Text("Nearby devices", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(4.dp))
    if (peers.isEmpty()) Text("Searching…", style = MaterialTheme.typography.bodySmall)
    peers.forEach { peer ->
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(peer.name)
            Button(onClick = { onConnect(peer) }) { Text("Connect") }
        }
    }
    Spacer(Modifier.height(12.dp))
    Text(
        "Connect to one phone for a chat, or several for a group. " +
            "Everyone must be within about 30 metres; no internet needed.",
        style = MaterialTheme.typography.bodySmall
    )
    Spacer(Modifier.height(24.dp))
    Text(
        stringResource(R.string.developed_by),
        style = MaterialTheme.typography.labelSmall
    )
}

// ---- small helpers ----

private fun reactionSummary(reactions: List<Reaction>, uid: String): String =
    reactions.filter { it.messageUid == uid }
        .groupingBy { it.emoji }
        .eachCount()
        .entries
        .joinToString(" ") { if (it.value > 1) "${it.key}${it.value}" else it.key }

private fun previewOf(message: Message): String = when (message.type) {
    MessageType.TEXT -> message.text.take(40)
    MessageType.IMAGE -> "Photo"
    MessageType.AUDIO -> "Voice note"
    MessageType.VIDEO -> "Video"
    else -> message.fileName ?: "File"
}

private fun typingText(names: Set<String>): String? = when {
    names.isEmpty() -> null
    names.size == 1 -> "${names.first()} is typing…"
    else -> "several people are typing…"
}

private fun formatTime(timestamp: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))

private fun isGameMessage(text: String): Boolean =
    text.startsWith("TTT:") || text.startsWith("RPS:") ||
        text.startsWith("RD:") || text.startsWith("DRAW:") || text == "DRAWCLEAR"

private fun newCacheUri(context: Context, extension: String): Uri {
    val dir = File(context.cacheDir, "images").apply { mkdirs() }
    val file = File(dir, "cap_${System.currentTimeMillis()}.$extension")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

private fun buzz(context: Context) {
    val vibrator = context.getSystemService(Vibrator::class.java) ?: return
    @Suppress("DEPRECATION")
    vibrator.vibrate(120)
}
