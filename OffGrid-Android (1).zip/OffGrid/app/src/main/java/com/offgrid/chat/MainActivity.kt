package com.offgrid.chat

import android.app.Activity
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.offgrid.chat.nearby.requiredPermissions
import com.offgrid.chat.ui.ChatScreen
import com.offgrid.chat.ui.ChatViewModel

class MainActivity : ComponentActivity() {

    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { /* denials surface in the Nearby status line */ }

        // Android 14+: tell the user (and the peer) when a screenshot is taken.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            registerScreenCaptureCallback(mainExecutor, object : Activity.ScreenCaptureCallback {
                override fun onScreenCaptured() {
                    vm.notifyLocalScreenshot()
                }
            })
        }

        setContent {
            var dark by remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ChatScreen(
                        vm = vm,
                        requestPermissions = { permissionLauncher.launch(requiredPermissions()) },
                        darkTheme = dark,
                        onToggleTheme = { dark = !dark }
                    )
                }
            }
        }
    }
}
