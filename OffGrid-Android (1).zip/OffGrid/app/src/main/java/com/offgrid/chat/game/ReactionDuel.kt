package com.offgrid.chat.game

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.offgrid.chat.data.Message
import kotlinx.coroutines.delay

/**
 * Reaction duel: wait for green, then tap as fast as you can.
 *
 * "RD:START" tells both phones to run the test (each measures its own reaction
 * locally, so no clock sync is needed). Each result is sent as
 * "RD:RESULT:<millis>"; the lower time wins.
 */
@Composable
fun ReactionDuelDialog(
    messages: List<Message>,
    onSend: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var phase by remember { mutableStateOf("idle") } // idle | waiting | go | done
    var myMs by remember { mutableStateOf<Long?>(null) }
    var goAt by remember { mutableStateOf(0L) }
    var trigger by remember { mutableStateOf(0) }

    // React to the peer starting a round.
    val peerStarts = messages.count { it.text == "RD:START" && !it.isMine }
    LaunchedEffect(peerStarts) {
        if (peerStarts > 0) trigger += 1
    }

    // Run a round whenever a start is triggered locally.
    LaunchedEffect(trigger) {
        if (trigger == 0) return@LaunchedEffect
        phase = "waiting"
        myMs = null
        delay((1500..4000).random().toLong())
        if (phase == "waiting") {
            phase = "go"
            goAt = System.currentTimeMillis()
        }
    }

    val lastStart = messages.indexOfLast { it.text == "RD:START" }
    val round = if (lastStart >= 0) messages.drop(lastStart + 1) else emptyList()
    val peerMs = round.lastOrNull { !it.isMine && it.text.startsWith("RD:RESULT:") }
        ?.text?.removePrefix("RD:RESULT:")?.toLongOrNull()

    val background = when (phase) {
        "waiting" -> Color(0xFFE53935)
        "go" -> Color(0xFF43A047)
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val prompt = when (phase) {
        "idle" -> "Tap Start, then tap the moment it turns green."
        "waiting" -> "Wait for green…"
        "go" -> "TAP!"
        else -> "Your time: ${myMs ?: "—"} ms"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Reaction duel") },
        text = {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(background, MaterialTheme.shapes.medium),
                    contentAlignment = Alignment.Center
                ) {
                    Text(prompt, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        when (phase) {
                            "idle", "done" -> {
                                onSend("RD:START")
                                trigger += 1
                            }
                            "go" -> {
                                val ms = System.currentTimeMillis() - goAt
                                myMs = ms
                                phase = "done"
                                onSend("RD:RESULT:$ms")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        when (phase) {
                            "idle", "done" -> "Start"
                            "waiting" -> "Wait…"
                            else -> "Tap!"
                        }
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text("You: ${myMs ?: "—"} ms")
                Text("Them: ${peerMs ?: "—"} ms")
                val mine = myMs
                val theirs = peerMs
                if (mine != null && theirs != null) {
                    Text(
                        when {
                            mine < theirs -> "You win"
                            mine > theirs -> "You lose"
                            else -> "Dead heat"
                        },
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    )
}
