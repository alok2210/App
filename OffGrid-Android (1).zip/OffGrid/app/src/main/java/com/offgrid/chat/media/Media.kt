package com.offgrid.chat.media

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Helpers for images, voice notes and arbitrary files.
 *
 * Small things travel as in-memory bytes; large ones go as Nearby file payloads
 * (the transport decides). Everything is encrypted before it leaves the phone.
 */
object MediaUtil {

    private const val MAX_IMAGE_DIM = 1024
    private const val JPEG_QUALITY = 70

    /** Persist bytes under the app's private files dir; returns the path. */
    fun saveToFiles(context: Context, bytes: ByteArray, extension: String): String {
        val dir = mediaDir(context)
        val file = File(dir, "m_${System.currentTimeMillis()}.$extension")
        file.writeBytes(bytes)
        return file.absolutePath
    }

    fun mediaDir(context: Context): File =
        File(context.filesDir, "media").apply { mkdirs() }

    /** Read, downscale and JPEG-compress an image chosen or captured by the user. */
    fun downscaleJpeg(context: Context, uri: Uri): ByteArray {
        val input = context.contentResolver.openInputStream(uri) ?: error("Cannot open image")
        val original = input.use { BitmapFactory.decodeStream(it) } ?: error("Cannot decode image")
        val scaled = scaleDown(original, MAX_IMAGE_DIM)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        return out.toByteArray()
    }

    private fun scaleDown(bitmap: Bitmap, maxDim: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxDim && h <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / maxOf(w, h)
        return Bitmap.createScaledBitmap(bitmap, (w * ratio).toInt(), (h * ratio).toInt(), true)
    }

    /** Copy a picked/captured file into our media dir; returns (path, fileName). */
    fun importFile(context: Context, uri: Uri, fallbackExt: String): Pair<String, String> {
        val name = displayName(context, uri) ?: "file_${System.currentTimeMillis()}.$fallbackExt"
        val target = File(mediaDir(context), "f_${System.currentTimeMillis()}_$name")
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Cannot open file")
        return target.absolutePath to name
    }

    fun readUriBytes(context: Context, uri: Uri): ByteArray =
        context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read")

    private fun displayName(context: Context, uri: Uri): String? {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) return cursor.getString(index)
        }
        return null
    }

    /** Open a stored media/file with whatever app the user prefers. */
    fun openFile(context: Context, path: String, fileName: String?) {
        val file = File(path)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val mime = guessMime(fileName ?: file.name)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Open with"))
    }

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg", "png", "webp" -> "image/*"
        "mp4", "3gp", "mkv", "webm" -> "video/*"
        "m4a", "aac", "mp3", "ogg", "wav" -> "audio/*"
        "pdf" -> "application/pdf"
        "txt" -> "text/plain"
        else -> "*/*"
    }
}

/** Records a short voice note to an AAC/m4a file. */
class AudioRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null

    @Suppress("DEPRECATION")
    fun start(): Boolean {
        return try {
            val file = File(MediaUtil.mediaDir(context), "rec_${System.currentTimeMillis()}.m4a")
            val mr = MediaRecorder()
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setOutputFile(file.absolutePath)
            mr.prepare()
            mr.start()
            recorder = mr
            outputFile = file
            true
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            false
        }
    }

    fun stop(): File? {
        val mr = recorder ?: return null
        return try {
            mr.stop(); mr.release(); outputFile
        } catch (e: Exception) {
            null
        } finally {
            recorder = null
        }
    }
}

/** Fire-and-forget playback of a local audio file. */
object AudioPlayer {
    private var player: MediaPlayer? = null

    fun play(path: String) {
        stop()
        player = MediaPlayer().apply {
            setDataSource(path)
            setOnCompletionListener { stop() }
            prepare()
            start()
        }
    }

    fun stop() {
        player?.let { runCatching { it.stop() }; it.release() }
        player = null
    }
}
