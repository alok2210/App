package com.offgrid.chat.game

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offgrid.chat.data.Message

/**
 * A two-player tic-tac-toe played over the same offline channel as chat.
 *
 * Each move is sent as the text "TTT:<cell>:<mark>". Both phones rebuild the
 * board by replaying those messages, so the two screens stay in sync without
 * any server. Marks are assigned deterministically: the device whose name
 * sorts first plays X. Both sides compute the same result, so they agree.
 */
@Composable
fun TicTacToeDialog(
    myName: String,
    peerName: String,
    messages: List<Message>,
    onSend: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val myMark = if (myName <= peerName) "X" else "O"
    val board = remember { mutableStateListOf(*Array(9) { "" }) }

    // Rebuild the board whenever a new move message arrives.
    LaunchedEffect(messages) {
        val moves = messages.mapNotNull { parseMove(it.text) }
        for (i in board.indices) board[i] = ""
        for ((index, mark) in moves) {
            if (index in 0..8) board[index] = mark
        }
    }

    val moveCount = board.count { it.isNotEmpty() }
    val turn = if (moveCount % 2 == 0) "X" else "O"
    val winner = winnerOf(board)
    val isDraw = winner == null && board.none { it.isEmpty() }
    val myTurn = winner == null && !isDraw && turn == myMark

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Tic-Tac-Toe") },
        text = {
            Column {
                Text(
                    when {
                        winner != null -> "Winner: $winner"
                        isDraw -> "It's a draw"
                        myTurn -> "Your turn — you are $myMark"
                        else -> "Waiting for $peerName…"
                    }
                )
                Spacer(Modifier.height(8.dp))
                for (row in 0..2) {
                    Row {
                        for (col in 0..2) {
                            val index = row * 3 + col
                            Surface(
                                modifier = Modifier
                                    .size(64.dp)
                                    .padding(4.dp)
                                    .clickable(enabled = myTurn && board[index].isEmpty()) {
                                        board[index] = myMark
                                        onSend("TTT:$index:$myMark")
                                    },
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.small
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(board[index], style = MaterialTheme.typography.headlineMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}

private fun parseMove(text: String): Pair<Int, String>? {
    if (!text.startsWith("TTT:")) return null
    val parts = text.split(":")
    if (parts.size != 3) return null
    val index = parts[1].toIntOrNull() ?: return null
    return index to parts[2]
}

private fun winnerOf(board: List<String>): String? {
    val lines = listOf(
        listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
        listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
        listOf(0, 4, 8), listOf(2, 4, 6)
    )
    for (line in lines) {
        val a = board[line[0]]
        if (a.isNotEmpty() && a == board[line[1]] && a == board[line[2]]) return a
    }
    return null
}
