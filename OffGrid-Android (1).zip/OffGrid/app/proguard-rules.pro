# Default ProGuard rules. Minification is disabled for this prototype,
# so this file is intentionally empty.
