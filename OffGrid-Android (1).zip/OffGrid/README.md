# OffGrid Chat

_Developed by Alok Kumar._

An Android messaging app that works **directly between nearby phones, with no
internet, no Wi-Fi router, no SIM, and no server** — plus a set of Snapchat-style
features and four games, all offline.

## Features

**Messaging & reach**
- Phone-to-phone over Bluetooth / Bluetooth LE / Wi-Fi Direct (Google Nearby
  Connections). No infrastructure at all.
- **Group chat** — connect to several phones; every message is broadcast.
- **Nickname** — set your own display name; peers see it.

**Privacy & security**
- **End-to-end encryption** — per-peer key agreed with **ECDH (P-256)**, run
  through HKDF, used for **AES-256-GCM**.
- **Safety number** — a 12-digit fingerprint both phones show, to compare out
  loud and rule out a man-in-the-middle.
- **Screenshot alert** — on Android 14+, both phones are told when a screenshot
  is taken.

**Snapchat-style**
- **Disappearing messages** — off / 10s / 1m / 1h; messages vanish from both
  phones on a timer.
- **Photo snaps** — a disappearing photo arrives hidden behind "Tap to view";
  opening it starts the countdown on both sides.
- **Emoji reactions** — long-press a message to react.
- **Reply-to** — long-press to quote and reply.

**Media & files**
- Photos from **gallery** or **camera**, **voice notes**, **video clips**, and
  **any file** (documents, archives…).
- Large media travels as a Nearby **file payload**; received media opens/plays
  in whatever app you prefer.

**Chat tools**
- **Typing indicator**, **read receipts** (✓ / ✓✓), **timestamps**.
- **Search**, **clear chat**, **export chat** to a text file.
- **Dark theme** toggle, auto-scroll, and a **"Ping"** buzz.

**Games** (one-to-one)
- Tic-tac-toe, rock-paper-scissors, reaction duel, shared doodle pad.

## How it works

- **Transport** (`nearby/NearbyManager.kt`) — advertises + discovers
  (`P2P_CLUSTER`), moves small payloads as bytes and large ones as file payloads.
- **Envelope** (`data/MessageCodec.kt`) — each radio payload is `KIND_CONTROL`
  (plaintext handshake: name + public key) or `KIND_ENCRYPTED` (AES-GCM). Inside
  is a typed message with a uid and JSON metadata (sender, reply, ttl, filename).
- **Encryption** (`crypto/CryptoManager.kt`) — one ephemeral EC key pair per
  device; per-peer ECDH → HKDF (salted with the Nearby pairing token) → AES key;
  a safety number is derived from both public keys + token.
- **Control channel** — typing, read, react, rename, screenshot and snap-open are
  small encrypted CONTROL messages, never stored.
- **Storage** (`data/Data.kt`) — Room tables for messages and reactions; media in
  `files/media`. Expiry is swept once a second; expired media files are deleted.
- **Media** (`media/Media.kt`) — image downscale, `MediaRecorder` voice notes,
  file import/open. Camera and video capture use the system camera app.
- **UI** (`ui/ChatScreen.kt`, `ui/ChatViewModel.kt`) — Compose.

## Project layout

```
OffGrid/app/src/main/java/com/offgrid/chat/
  MainActivity.kt            # theme state, screenshot callback
  nearby/NearbyManager.kt    # transport
  crypto/CryptoManager.kt    # ECDH + AES-GCM + safety number
  data/Data.kt               # Room: messages + reactions
  data/MessageCodec.kt       # envelope + wire format + control actions
  media/Media.kt             # images, voice, files, open/play
  ui/ChatViewModel.kt        # all the glue
  ui/ChatScreen.kt           # chat UI
  game/*.kt                  # four games
OffGrid/app/src/main/res/xml/file_paths.xml
OffGrid/app/src/main/AndroidManifest.xml
```

## Build with no laptop (free cloud build)

The project ships with a GitHub Actions workflow
(`.github/workflows/build.yml`) that builds the APK in the cloud. You can do
this entirely from a phone:

1. Make a free **GitHub** account and create a new **repository** (browser on the
   phone is fine).
2. In the repo: **Add file → Upload files**, and upload **`OffGrid-Android.zip`**
   (just that one file — the workflow unpacks it for you). Commit.
3. Open the repo's **Actions** tab. The **Build APK** workflow starts on its own
   (or tap **Run workflow**). Wait a few minutes for a green tick.
4. Open the finished run and download the **OffGrid-debug-apk** artifact.
5. Unzip it and install **`OffGridChat.apk`** on your phone (allow "install
   unknown apps" for the app you unzip with).

That's it — no computer involved. Every time you change the code and upload it
again, a fresh APK is built for you.

## Build and run (with a computer)

1. Android Studio (Koala+) with SDK for API 34. Open the `OffGrid` folder; let
   Gradle sync (let it regenerate the Gradle wrapper if asked).
2. Run on **two or more** Android phones (API 24+). Real phones beat emulators.
3. Grant the prompts (nearby devices, location, microphone).
4. Tap **Connect** next to a peer (or several, for a group).
5. **Compare the safety number** — matching numbers mean a secure link.
6. Send text; **+** attaches a photo / camera / video / file; **Rec** records
   voice; **Timer** sets disappearing messages; **Games** (one-to-one); **Menu**
   has name, theme, ping, export, clear.

## Limitations (please read)

- **Range** ~10–30 m — physics, with no infrastructure.
- **Not a mesh.** Phones must be in range of each other; there is no relaying.
- **Snap countdown starts on open** (recipient-triggered), not on send.
- **Large files** are read fully into memory to decrypt.
- **Handshake trust.** Public keys are exchanged in the clear; the safety number
  is what rules out a MITM. A production app would add key continuity + a
  ratchet for forward secrecy.
- **Reactions** are stored, but **revealed-snap state** is in memory only.
- **Screenshot alert** needs Android 14+ and is best-effort.
- Written but **not compiled** in the environment that generated it (no Android
  SDK there). Targets AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.09.00. Accept
  Android Studio's upgrade suggestions if your versions differ.

## Deliberately not included (each is its own project)

- **BLE mesh with store-and-forward** (longer range by relaying through phones).
- **Double ratchet / forward secrecy.**
- **Live voice/video calls** over the radio link.
- **Streaming decryption** for very large media.
- **Avatars** and **stories**.

These are large enough that bolting them on untested would break the app; they're
best done one at a time as follow-ups.
